
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/api.mjs
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { getDatabase } from "@netlify/database";

// shared/catalog.js
var seedProducts = [
  {
    id: "sculpt-seamless-leggings",
    name: "Sculpt Seamless Leggings",
    price: 78,
    tag: "BEST SELLER",
    tone: "rose",
    image: "/images/fit-variants/sculpt-seamless-leggings/black.webp",
    description: "A smooth, supportive high-rise legging for everyday movement.",
    gender: "women",
    category: "leggings",
    subcategory: "sculpt seamless",
    collection: "Sculpt Seamless",
    activity: "train",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Maroon", "Teal", "Dark Blue", "Baby Blue", "White"],
    featured: true,
    bestSeller: true,
    trendingMode: "on",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 24
  },
  {
    id: "everyday-form-bra",
    name: "Everyday Form Bra",
    price: 52,
    tag: "NEW COLOUR",
    tone: "sand",
    image: "/images/women-coastal-studio.jpg",
    description: "A considered essential with easy, comfortable support.",
    gender: "women",
    category: "sports bras",
    subcategory: "everyday support",
    collection: "Everyday Essentials",
    activity: "studio",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Black", "Maroon", "Teal", "Dark Blue", "Baby Blue", "White"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 18
  },
  {
    id: "studio-rib-tank",
    name: "Studio Rib Tank",
    price: 46,
    tag: "JUST LANDED",
    tone: "rose",
    image: "/images/women-solo-pink-studio.jpg",
    description: "A light ribbed layer made for the studio and beyond.",
    gender: "women",
    category: "tops",
    subcategory: "ribbed tanks",
    collection: "Everyday Essentials",
    activity: "studio",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Black", "Maroon", "Teal", "Dark Blue", "Baby Blue", "White"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 31
  },
  {
    id: "move-with-ease-short",
    name: "Move With Ease Short",
    price: 58,
    tag: "LOW STOCK",
    tone: "green",
    image: "/images/women-solo-galle-run.jpg",
    description: "An easy short for coastal runs and slow mornings.",
    gender: "women",
    category: "shorts",
    subcategory: "run shorts",
    collection: "Coastline",
    activity: "run",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Maroon", "Teal", "Dark Blue", "Baby Blue", "White"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: true,
    salePrice: 49,
    active: true,
    stock: 8
  },
  {
    id: "elephant-trail-flare-leggings",
    name: "Elephant Trail Flare Leggings",
    price: 82,
    tag: "SRI LANKA EDIT",
    tone: "sand",
    image: "/images/fit-variants/elephant-trail-flare-leggings/black.webp",
    description: "Smooth, solid-color flared training leggings inspired by Sri Lanka\u2019s coastal trails.",
    gender: "women",
    category: "leggings",
    subcategory: "flared leggings",
    collection: "Sri Lanka Edit",
    activity: "train",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Maroon", "Teal", "Dark Blue", "Baby Blue", "White"],
    featured: true,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 20
  },
  {
    id: "coastal-training-tee",
    name: "Coastal Training Tee",
    price: 62,
    tag: "NEW SEASON",
    tone: "sand",
    image: "/images/men-training.jpg",
    description: "A breathable training layer for warm-weather miles.",
    gender: "men",
    category: "tops",
    subcategory: "training tees",
    collection: "Coastal Run",
    activity: "run",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Sand", "Black"],
    featured: true,
    bestSeller: false,
    trendingMode: "on",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 22
  },
  {
    id: "hybrid-training-short",
    name: "Hybrid Training Short",
    price: 66,
    tag: "BUILT TO MOVE",
    tone: "blue",
    image: "/images/men-galle-run.jpg",
    description: "Easy movement and secure storage for every session.",
    gender: "men",
    category: "shorts",
    subcategory: "training shorts",
    collection: "Training Edit",
    activity: "train",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Navy", "Black"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: true,
    salePrice: 54,
    active: true,
    stock: 19
  },
  {
    id: "everyday-training-tight",
    name: "Everyday Training Tight",
    price: 72,
    tag: "TRAINING ESSENTIAL",
    tone: "green",
    image: "/images/men-solo-kettlebell.jpg",
    description: "A versatile base layer for training and recovery.",
    gender: "men",
    category: "tights",
    subcategory: "training tights",
    collection: "Training Edit",
    activity: "train",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Moss"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 15
  },
  {
    id: "coastal-oversized-top",
    name: "Coastal Oversized Top",
    price: 58,
    tag: "EASY LAYER",
    tone: "sand",
    image: "/images/men-training.jpg",
    description: "A relaxed, breathable layer for warm-ups and easy days.",
    gender: "men",
    category: "tops",
    subcategory: "oversized tops",
    collection: "Everyday Movement",
    activity: "everyday",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Sand", "Black"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 20
  },
  {
    id: "training-zip-layer",
    name: "Training Zip Layer",
    price: 84,
    tag: "LIGHT LAYER",
    tone: "blue",
    image: "/images/men-solo-kettlebell.jpg",
    description: "A light, flexible layer for early starts and post-session recovery.",
    gender: "men",
    category: "layers",
    subcategory: "training layers",
    collection: "Training Edit",
    activity: "train",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Slate", "Black"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 13
  },
  {
    id: "coastline-training-socks",
    name: "Coastline Training Socks",
    price: 18,
    tag: "EVERYDAY PAIR",
    tone: "sand",
    image: "/images/coastal-training-accessories.jpg",
    description: "Soft, breathable support from warm-up to wind-down.",
    gender: "accessories",
    category: "socks",
    subcategory: "crew socks",
    collection: "Coastal Run",
    activity: "run",
    sizes: ["S/M", "L/XL"],
    colors: ["White", "Black"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 40
  },
  {
    id: "saltline-training-tote",
    name: "Saltline Training Tote",
    price: 48,
    tag: "FEATURED",
    tone: "green",
    image: "/images/coastal-training-accessories.jpg",
    description: "A roomy carry-all for training days and coastal escapes.",
    gender: "accessories",
    category: "bags",
    subcategory: "training bags",
    collection: "Everyday Essentials",
    activity: "everyday",
    sizes: ["One size"],
    colors: ["Moss", "Black"],
    featured: true,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 12
  },
  {
    id: "coastal-run-cap",
    name: "Coastal Run Cap",
    price: 32,
    tag: "COASTAL RUN",
    tone: "blue",
    image: "/images/men-galle-run.jpg",
    description: "Lightweight shade for early starts and open roads.",
    gender: "accessories",
    category: "headwear",
    subcategory: "caps",
    collection: "Coastal Run",
    activity: "run",
    sizes: ["One size"],
    colors: ["Navy", "White"],
    featured: false,
    bestSeller: false,
    trendingMode: "on",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 17
  },
  {
    id: "resistance-band-set",
    name: "Resistance Band Set",
    price: 28,
    tag: "TRAIN ANYWHERE",
    tone: "rose",
    image: "/images/coastal-training-accessories.jpg",
    description: "A compact set for warm-ups, strength and recovery.",
    gender: "accessories",
    category: "equipment",
    subcategory: "training accessories",
    collection: "Training Edit",
    activity: "train",
    sizes: ["One size"],
    colors: ["Rose", "Teal"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: true,
    salePrice: 22,
    active: true,
    stock: 26
  },
  {
    id: "everyday-base-layer",
    name: "Everyday Base Layer",
    price: 34,
    tag: "SOFT ESSENTIAL",
    tone: "sand",
    image: "/images/men-solo-kettlebell.jpg",
    description: "A soft, easy-fitting layer made for everyday comfort.",
    gender: "accessories",
    category: "underwear",
    subcategory: "everyday underwear",
    collection: "Everyday Essentials",
    activity: "everyday",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Sand"],
    featured: false,
    bestSeller: false,
    trendingMode: "auto",
    unitsSold: 0,
    onSale: false,
    active: true,
    stock: 21
  }
];
seedProducts.forEach((product, index) => {
  product.createdAt = new Date(Date.UTC(2026, 9, index + 1)).toISOString();
});

// netlify/functions/api.mjs
var database = getDatabase();
var adminEmail = process.env.ADMIN_EMAIL || "owner@saltlynelabel.com";
var sessionSecret = process.env.ADMIN_SESSION_SECRET || "";
var sessionCookie = "saltlyne_session";
var retiredProductIds = /* @__PURE__ */ new Set(["coastline-leggings"]);
var ApiError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
function json(status, value, headers = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
  });
}
async function readBody(request) {
  const text = await request.text();
  if (text.length > 1e6) throw new ApiError(413, "Request too large.");
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    throw new ApiError(400, "Invalid JSON request.");
  }
}
function constantTimeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && timingSafeEqual(a, b);
}
function signSession(payload) {
  return createHmac("sha256", sessionSecret).update(payload).digest("base64url");
}
function getSessionToken(request) {
  return (request.headers.get("cookie") || "").split(";").map((part) => part.trim()).find((part) => part.startsWith(`${sessionCookie}=`))?.slice(sessionCookie.length + 1) || "";
}
function isAuthenticated(request) {
  if (!sessionSecret) return false;
  const [payload, signature] = getSessionToken(request).split(".");
  if (!payload || !signature) return false;
  const expected = signSession(payload);
  if (!constantTimeEqual(signature, expected)) return false;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")).expires > Date.now();
  } catch {
    return false;
  }
}
function requireAdmin(request) {
  if (!isAuthenticated(request)) throw new ApiError(401, "Sign in required.");
}
function cookieHeader(token, maxAge, secure) {
  return `${sessionCookie}=${token}; HttpOnly; ${secure ? "Secure; " : ""}SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}
function normalizeProduct(product) {
  const { isTrending: _isTrending, isBestSeller: _isBestSeller, ...record } = product;
  return record;
}
async function seedIfEmpty() {
  const counts = await database.sql`SELECT (SELECT COUNT(*) FROM products) AS count`;
  if (Number(counts[0]?.count) > 0) return;
  const values = seedProducts.filter((product) => !retiredProductIds.has(product.id)).map((product) => [product.id, product.createdAt || (/* @__PURE__ */ new Date()).toISOString(), JSON.stringify(normalizeProduct(product))]);
  if (values.length) {
    const rows = database.sql.values(values);
    await database.sql`INSERT INTO products (id, created_at, data) VALUES ${rows} ON CONFLICT (id) DO NOTHING`;
  }
}
async function productRecords(activeOnly = false) {
  await seedIfEmpty();
  return activeOnly ? database.sql`SELECT data FROM products WHERE COALESCE((data->>'active')::boolean, false) = true ORDER BY created_at DESC` : database.sql`SELECT data FROM products ORDER BY created_at DESC`;
}
function productsWithMerchandising(products) {
  const topIdsByDepartment = (eligible) => {
    const departments = /* @__PURE__ */ new Map();
    for (const product of products) {
      if (!product.active || !eligible(product)) continue;
      const departmentProducts = departments.get(product.gender) || [];
      departmentProducts.push(product);
      departments.set(product.gender, departmentProducts);
    }
    return new Set([...departments.values()].flatMap((departmentProducts) => departmentProducts.sort((a, b) => Number(b.unitsSold) - Number(a.unitsSold)).slice(0, 3).map((product) => product.id)));
  };
  const autoTrendingIds = topIdsByDepartment((product) => product.trendingMode === "auto" && Number(product.unitsSold) > 0);
  const bestSellerIds = topIdsByDepartment((product) => Number(product.unitsSold) > 0);
  return products.map((product) => ({
    ...product,
    isTrending: product.trendingMode === "on" || product.trendingMode === "auto" && autoTrendingIds.has(product.id),
    isBestSeller: Boolean(product.bestSeller || bestSellerIds.has(product.id))
  }));
}
function parsePath(pathname) {
  const functionPrefix = "/.netlify/functions/api";
  if (pathname.startsWith(functionPrefix)) return `/api${pathname.slice(functionPrefix.length)}`;
  return pathname;
}
async function handle(request) {
  const url = new URL(request.url);
  const route = parsePath(url.pathname);
  const method = request.method.toUpperCase();
  if (method === "OPTIONS") return new Response(null, { status: 204, headers: { "access-control-allow-methods": "GET, POST, PATCH, DELETE, OPTIONS", "access-control-allow-headers": "content-type" } });
  if (route === "/api/health" && method === "GET") return json(200, { ok: true });
  if (route === "/api/products" && method === "GET") {
    const rows = await productRecords(true);
    return json(200, productsWithMerchandising(rows.map((row) => row.data)));
  }
  if (route === "/api/auth/login" && method === "POST") {
    const password = process.env.ADMIN_PASSWORD;
    if (!password || !sessionSecret) throw new ApiError(503, "Admin login is not configured. Set ADMIN_PASSWORD and ADMIN_SESSION_SECRET.");
    const credentials = await readBody(request);
    if (String(credentials.email || "").toLowerCase() !== adminEmail.toLowerCase() || !constantTimeEqual(credentials.password || "", password)) {
      throw new ApiError(401, "Email or password is incorrect.");
    }
    const payload = Buffer.from(JSON.stringify({ expires: Date.now() + 12 * 60 * 60 * 1e3, nonce: randomBytes(16).toString("hex") })).toString("base64url");
    return json(200, { email: adminEmail }, { "set-cookie": cookieHeader(`${payload}.${signSession(payload)}`, 43200, url.protocol === "https:") });
  }
  if (route === "/api/auth/me" && method === "GET") return isAuthenticated(request) ? json(200, { email: adminEmail }) : json(401, { error: "Sign in required." });
  if (route === "/api/auth/logout" && method === "POST") return json(200, { ok: true }, { "set-cookie": cookieHeader("", 0, url.protocol === "https:") });
  if (route.startsWith("/api/admin/")) requireAdmin(request);
  if (route === "/api/admin/summary" && method === "GET") {
    const [products, orders] = await Promise.all([productRecords(), database.sql`SELECT status, total FROM orders`]);
    const allProducts = products.map((row) => row.data);
    return json(200, {
      products: allProducts.length,
      activeProducts: allProducts.filter((product) => product.active).length,
      orders: orders.length,
      revenue: orders.filter((order) => order.status !== "cancelled").reduce((sum, order) => sum + Number(order.total), 0),
      lowStock: allProducts.filter((product) => product.stock < 10).length
    });
  }
  if (route === "/api/admin/products" && method === "GET") {
    const rows = await productRecords();
    return json(200, productsWithMerchandising(rows.map((row) => row.data)));
  }
  if (route === "/api/admin/products" && method === "POST") {
    const product = await readBody(request);
    const item = normalizeProduct({
      ...product,
      id: `product-${randomBytes(5).toString("hex")}`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      name: String(product.name || "New product").trim(),
      price: Number(product.price) || 0,
      tag: String(product.tag || "NEW"),
      tone: String(product.tone || "sand"),
      image: String(product.image || "/images/women-training.jpg"),
      description: String(product.description || ""),
      gender: String(product.gender || "women"),
      category: String(product.category || "tops"),
      subcategory: String(product.subcategory || "essentials"),
      collection: String(product.collection || "Everyday Essentials"),
      activity: String(product.activity || "everyday"),
      sizes: Array.isArray(product.sizes) ? product.sizes : [],
      colors: Array.isArray(product.colors) ? product.colors : [],
      featured: Boolean(product.featured),
      bestSeller: Boolean(product.bestSeller),
      trendingMode: ["auto", "on", "off"].includes(product.trendingMode) ? product.trendingMode : "auto",
      unitsSold: 0,
      onSale: Boolean(product.onSale),
      salePrice: Number(product.salePrice) || void 0,
      active: Boolean(product.active),
      stock: Math.max(0, Number(product.stock) || 0)
    });
    await database.sql`INSERT INTO products (id, created_at, data) VALUES (${item.id}, ${item.createdAt}, ${JSON.stringify(item)}::jsonb)`;
    return json(201, item);
  }
  const productMatch = route.match(/^\/api\/admin\/products\/([^/]+)$/);
  if (productMatch && method === "PATCH") {
    const id = decodeURIComponent(productMatch[1]);
    const changes = await readBody(request);
    const rows = await database.sql`SELECT data FROM products WHERE id = ${id}`;
    if (!rows.length) throw new ApiError(404, "Product not found.");
    const current = rows[0].data;
    delete changes.isTrending;
    delete changes.isBestSeller;
    const item = normalizeProduct({
      ...current,
      ...changes,
      id,
      name: String(changes.name ?? current.name).trim(),
      price: Number(changes.price ?? current.price),
      stock: Math.max(0, Number(changes.stock ?? current.stock)),
      active: Boolean(changes.active ?? current.active),
      featured: Boolean(changes.featured ?? current.featured),
      bestSeller: Boolean(changes.bestSeller ?? current.bestSeller),
      trendingMode: ["auto", "on", "off"].includes(changes.trendingMode) ? changes.trendingMode : current.trendingMode,
      unitsSold: current.unitsSold,
      sizes: Array.isArray(changes.sizes) ? changes.sizes : current.sizes,
      colors: Array.isArray(changes.colors) ? changes.colors : current.colors,
      onSale: Boolean(changes.onSale ?? current.onSale),
      salePrice: Number(changes.salePrice ?? current.salePrice) || void 0
    });
    const updated = await database.sql`UPDATE products SET data = ${JSON.stringify(item)}::jsonb WHERE id = ${id} RETURNING data`;
    return json(200, updated[0].data);
  }
  if (productMatch && method === "DELETE") {
    const id = decodeURIComponent(productMatch[1]);
    await database.sql`DELETE FROM products WHERE id = ${id}`;
    return json(200, { ok: true });
  }
  if (route === "/api/admin/orders" && method === "GET") {
    const rows = await database.sql`SELECT data, status FROM orders ORDER BY created_at DESC`;
    return json(200, rows.map((row) => ({ ...row.data, status: row.status })));
  }
  const orderMatch = route.match(/^\/api\/admin\/orders\/([^/]+)$/);
  if (orderMatch && method === "PATCH") {
    const id = decodeURIComponent(orderMatch[1]);
    const changes = await readBody(request);
    const nextStatus = ["pending", "processing", "shipped", "completed", "cancelled"].includes(changes.status) ? changes.status : null;
    if (!nextStatus) throw new ApiError(400, "Invalid order status.");
    const client = await database.pool.connect();
    try {
      await client.query("BEGIN");
      const result = await client.query("SELECT data, status FROM orders WHERE id = $1 FOR UPDATE", [id]);
      if (!result.rows.length) throw new ApiError(404, "Order not found.");
      const order = result.rows[0].data;
      const previousStatus = result.rows[0].status;
      if (previousStatus === "cancelled" && nextStatus !== "cancelled") throw new ApiError(409, "Cancelled orders cannot be reopened.");
      if (nextStatus === "cancelled" && previousStatus !== "cancelled") {
        for (const line of order.items) {
          const productResult = await client.query("SELECT data FROM products WHERE id = $1 FOR UPDATE", [line.id]);
          if (productResult.rows.length) {
            const product = productResult.rows[0].data;
            product.stock = Number(product.stock || 0) + line.quantity;
            product.unitsSold = Math.max(0, Number(product.unitsSold || 0) - line.quantity);
            await client.query("UPDATE products SET data = $2::jsonb WHERE id = $1", [line.id, JSON.stringify(product)]);
          }
        }
      }
      await client.query("UPDATE orders SET status = $2, data = jsonb_set(data, '{status}', to_jsonb($2::text)) WHERE id = $1", [id, nextStatus]);
      await client.query("COMMIT");
      return json(200, { ...order, status: nextStatus });
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
  if (route === "/api/orders" && method === "POST") {
    const orderData = await readBody(request);
    if (!Array.isArray(orderData.items) || !orderData.items.length || !orderData.email || !orderData.name) {
      throw new ApiError(400, "Add items and complete your contact and delivery details.");
    }
    const requested = /* @__PURE__ */ new Map();
    for (const line of orderData.items) {
      const quantity = Math.max(1, Math.min(20, Number(line.quantity) || 1));
      requested.set(line.id, (requested.get(line.id) || 0) + quantity);
    }
    const client = await database.pool.connect();
    try {
      await client.query("BEGIN");
      const productIds = [...requested.keys()].sort();
      const productResult = await client.query("SELECT id, data FROM products WHERE id = ANY($1::text[]) ORDER BY id FOR UPDATE", [productIds]);
      const products = new Map(productResult.rows.map((row) => [row.id, row.data]));
      const lines = orderData.items.map((line) => {
        const product = products.get(line.id);
        if (!product || !product.active) throw new ApiError(400, "A product in this order is no longer available.");
        const requestedSize = typeof line.size === "string" ? line.size.trim() : "";
        if (requestedSize && Array.isArray(product.sizes) && !product.sizes.includes(requestedSize)) throw new ApiError(400, `${requestedSize} is not available for ${product.name}.`);
        const price = product.onSale && Number(product.salePrice) > 0 && Number(product.salePrice) < Number(product.price) ? Number(product.salePrice) : Number(product.price);
        return { id: product.id, name: product.name, size: requestedSize || void 0, price, quantity: Math.max(1, Math.min(20, Number(line.quantity) || 1)) };
      });
      for (const [productId, quantity] of requested) {
        const product = products.get(productId);
        if (Number(product.stock) < quantity) throw new ApiError(400, `${product.name} does not have enough stock for this order.`);
      }
      for (const [productId, quantity] of requested) {
        const product = products.get(productId);
        product.stock = Number(product.stock) - quantity;
        product.unitsSold = Number(product.unitsSold || 0) + quantity;
        await client.query("UPDATE products SET data = $2::jsonb WHERE id = $1", [productId, JSON.stringify(product)]);
      }
      const order = {
        id: `SL-${Date.now().toString(36).toUpperCase()}`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        customer: { email: String(orderData.email), name: String(orderData.name), address: String(orderData.address || "") },
        items: lines,
        total: lines.reduce((sum, line) => sum + line.price * line.quantity, 0),
        status: "pending"
      };
      await client.query("INSERT INTO orders (id, created_at, status, total, data) VALUES ($1, $2, $3, $4, $5::jsonb)", [order.id, order.createdAt, order.status, order.total, JSON.stringify(order)]);
      await client.query("COMMIT");
      return json(201, { id: order.id, status: order.status });
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
  if (route.startsWith("/api/")) throw new ApiError(404, "Not found.");
  return json(404, { error: "Not found." });
}
async function handler(request) {
  try {
    return await handle(request);
  } catch (error) {
    if (error instanceof ApiError) return json(error.status, { error: error.message });
    console.error("Netlify API error:", error);
    return json(500, { error: "The store service is temporarily unavailable." });
  }
}
export {
  handler as default
};
